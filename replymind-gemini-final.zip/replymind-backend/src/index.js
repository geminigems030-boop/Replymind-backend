// src/index.js
// ─────────────────────────────────────────────────────────
// ReplyMind — Express Server Entry Point
// ─────────────────────────────────────────────────────────

require("dotenv").config();
const express = require("express");
const morgan = require("morgan");

const webhookRouter = require("./routes/webhook");
const apiRouter = require("./routes/api");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────

// Save raw body BEFORE json parsing (needed for Meta signature verification)
app.use((req, res, next) => {
  let raw = "";
  req.on("data", (chunk) => (raw += chunk));
  req.on("end", () => {
    req.rawBody = raw;
    next();
  });
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev")); // HTTP request logging

// CORS — allow dashboard frontend to call the API
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// ── Routes ─────────────────────────────────────────────────
app.use("/webhook", webhookRouter);   // Meta webhook
app.use("/api", apiRouter);           // Dashboard API

// Root health check
app.get("/", (req, res) => {
  res.json({
    service: "ReplyMind API",
    version: "1.0.0",
    status: "running",
    docs: "See README.md for setup instructions",
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Error handler
app.use((err, req, res, next) => {
  console.error("[Error]", err.message);
  res.status(500).json({ error: "Internal server error" });
});

// ── Start ──────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 ReplyMind running on http://localhost:${PORT}`);
  console.log(`   Webhook URL: http://localhost:${PORT}/webhook/instagram`);
  console.log(`   API:         http://localhost:${PORT}/api`);
  console.log(`   Environment: ${process.env.NODE_ENV || "development"}\n`);
});

module.exports = app;
