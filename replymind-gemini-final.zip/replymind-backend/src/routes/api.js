// src/routes/api.js
// ─────────────────────────────────────────────────────────
// REST API consumed by the ReplyMind dashboard frontend.
// ─────────────────────────────────────────────────────────

const express = require("express");
const { generateReply } = require("../services/aiService");
const { replyToDM, replyToComment, getAccountInfo } = require("../services/instagramService");
const {
  getQueue,
  getEscalations,
  approveQueueItem,
  resolveEscalation,
} = require("../services/replyPipeline");
const { getClient, getAllClients } = require("../../config/clients");

const router = express.Router();

// ── Health check ───────────────────────────────────────────
router.get("/health", async (req, res) => {
  try {
    const account = await getAccountInfo();
    res.json({ status: "ok", instagram: account });
  } catch (err) {
    res.json({ status: "ok", instagram: "not connected", error: err.message });
  }
});

// ── Generate a reply (test or manual) ─────────────────────
// POST /api/reply
// Body: { client_id, message_type, from_user, message, auto_send }
router.post("/reply", async (req, res) => {
  const { client_id, message_type, from_user, message, auto_send, target_id } = req.body;

  if (!client_id || !message) {
    return res.status(400).json({ error: "client_id and message are required" });
  }

  const clientConfig = getClient(client_id);
  if (!clientConfig) {
    return res.status(404).json({ error: `Client not found: ${client_id}` });
  }

  try {
    const { reply, confidence } = await generateReply({
      message,
      messageType: message_type || "dm",
      fromUser: from_user || "unknown",
      clientConfig,
    });

    // Optionally send immediately
    if (auto_send && target_id) {
      if (message_type === "comment") {
        await replyToComment(target_id, reply);
      } else {
        await replyToDM(target_id, reply);
      }
      return res.json({ reply, confidence, sent: true });
    }

    res.json({ reply, confidence, sent: false });
  } catch (err) {
    console.error("[API] Reply generation error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Queue endpoints ────────────────────────────────────────

// GET /api/queue — list pending replies
router.get("/queue", (req, res) => {
  const { client_id } = req.query;
  let queue = getQueue();
  if (client_id) queue = queue.filter((i) => i.clientId === client_id);
  res.json({ queue, total: queue.length });
});

// POST /api/queue/:id/approve — approve and send a queued reply
router.post("/queue/:id/approve", async (req, res) => {
  const item = approveQueueItem(req.params.id);
  if (!item) return res.status(404).json({ error: "Queue item not found" });

  try {
    if (item.messageType === "comment") {
      await replyToComment(item.senderId, item.aiReply);
    } else {
      await replyToDM(item.senderId, item.aiReply);
    }
    res.json({ success: true, sent: item.aiReply });
  } catch (err) {
    res.status(500).json({ error: `Failed to send: ${err.message}` });
  }
});

// POST /api/queue/:id/approve — approve with an edited reply
router.post("/queue/:id/approve-edited", async (req, res) => {
  const { edited_reply } = req.body;
  const item = approveQueueItem(req.params.id);
  if (!item) return res.status(404).json({ error: "Queue item not found" });

  try {
    if (item.messageType === "comment") {
      await replyToComment(item.senderId, edited_reply || item.aiReply);
    } else {
      await replyToDM(item.senderId, edited_reply || item.aiReply);
    }
    res.json({ success: true, sent: edited_reply || item.aiReply });
  } catch (err) {
    res.status(500).json({ error: `Failed to send: ${err.message}` });
  }
});

// ── Escalation endpoints ───────────────────────────────────

// GET /api/escalations
router.get("/escalations", (req, res) => {
  const { client_id, status } = req.query;
  let items = getEscalations();
  if (client_id) items = items.filter((i) => i.clientId === client_id);
  if (status) items = items.filter((i) => i.status === status);
  res.json({ escalations: items, total: items.length });
});

// POST /api/escalations/:id/resolve
router.post("/escalations/:id/resolve", (req, res) => {
  const ok = resolveEscalation(req.params.id);
  if (!ok) return res.status(404).json({ error: "Escalation not found" });
  res.json({ success: true });
});

// ── Client endpoints ───────────────────────────────────────

// GET /api/clients
router.get("/clients", (req, res) => {
  const clients = getAllClients().map((c) => ({
    id: c.id,
    name: c.name,
    handle: c.handle,
    tone: c.tone,
    features: c.features,
  }));
  res.json({ clients });
});

// GET /api/clients/:id
router.get("/clients/:id", (req, res) => {
  const client = getClient(req.params.id);
  if (!client) return res.status(404).json({ error: "Client not found" });
  res.json({ client });
});

module.exports = router;
