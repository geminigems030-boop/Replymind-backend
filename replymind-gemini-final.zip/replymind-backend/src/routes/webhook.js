// src/routes/webhook.js
// ─────────────────────────────────────────────────────────
// Instagram Webhook Handler
//
// Two endpoints:
//   GET  /webhook/instagram  — Meta verification challenge
//   POST /webhook/instagram  — Incoming DM / comment events
// ─────────────────────────────────────────────────────────

const express = require("express");
const crypto = require("crypto");
const { processDM, processComment } = require("../services/replyPipeline");

const router = express.Router();

// ── GET: Meta Webhook Verification ────────────────────────
// When you add your webhook URL in Meta's developer portal,
// Meta sends a GET request to verify ownership.
router.get("/instagram", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token === process.env.INSTAGRAM_VERIFY_TOKEN) {
    console.log("[Webhook] ✅ Verification successful");
    res.status(200).send(challenge); // Echo back the challenge to confirm
  } else {
    console.warn("[Webhook] ❌ Verification failed — token mismatch");
    res.sendStatus(403);
  }
});

// ── POST: Incoming Events ──────────────────────────────────
router.post("/instagram", (req, res) => {
  // Always respond 200 immediately — Meta will retry if you don't
  res.sendStatus(200);

  // Verify the request came from Meta (security check)
  if (!verifySignature(req)) {
    console.warn("[Webhook] ❌ Invalid signature — ignoring request");
    return;
  }

  const body = req.body;

  if (body.object !== "instagram") {
    return; // Not an Instagram event, ignore
  }

  // Process each entry asynchronously (don't block the response)
  for (const entry of body.entry || []) {
    handleEntry(entry).catch((err) => {
      console.error("[Webhook] Error handling entry:", err.message);
    });
  }
});

// ── Event Router ──────────────────────────────────────────
async function handleEntry(entry) {
  const pageId = entry.id;

  // ── Direct Messages ──
  for (const event of entry.messaging || []) {
    // Ignore message echoes (your own sent messages)
    if (event.message?.is_echo) continue;
    // Ignore read receipts and typing indicators
    if (!event.message?.text) continue;

    await processDM({
      pageId,
      senderId: event.sender.id,
      senderName: event.sender.username || event.sender.id,
      message: event.message.text,
    });
  }

  // ── Post Comments ──
  for (const change of entry.changes || []) {
    if (change.field !== "comments") continue;

    const comment = change.value;

    // Don't reply to your own comments
    if (comment.from?.id === pageId) continue;
    // Don't reply to comments with no text
    if (!comment.text) continue;

    await processComment({
      pageId,
      commentId: comment.id,
      senderName: comment.from?.username || "someone",
      message: comment.text,
    });
  }
}

// ── Signature Verification ────────────────────────────────
// Validates that the POST came from Meta, not a third party
function verifySignature(req) {
  // Skip in development if secret not set
  if (!process.env.INSTAGRAM_APP_SECRET) {
    if (process.env.NODE_ENV === "development") return true;
    return false;
  }

  const signature = req.headers["x-hub-signature-256"];
  if (!signature) return false;

  const expected = "sha256=" + crypto
    .createHmac("sha256", process.env.INSTAGRAM_APP_SECRET)
    .update(req.rawBody || JSON.stringify(req.body))
    .digest("hex");

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}

module.exports = router;
