// src/utils/escalationDetector.js
// ─────────────────────────────────────────────────────────
// Detects messages that need human attention before the AI
// even tries to reply. Catches complaints, refunds, legal
// threats, and other sensitive topics.
// ─────────────────────────────────────────────────────────

const ESCALATION_TRIGGERS = {
  // Financial
  refund: "Refund request",
  "money back": "Refund request",
  chargeback: "Chargeback threat",
  dispute: "Payment dispute",
  fraud: "Fraud claim",
  scam: "Scam accusation",
  stolen: "Theft/fraud claim",

  // Legal
  lawsuit: "Legal threat",
  lawyer: "Legal threat",
  attorney: "Legal threat",
  "sue you": "Legal threat",
  "take you to court": "Legal threat",
  "report you": "Regulatory threat",

  // Negative experience
  "absolutely terrible": "Negative experience",
  "worst experience": "Negative experience",
  "never coming back": "Negative experience",
  "rip off": "Negative experience",
  "waste of money": "Negative experience",

  // Public threats
  "leave a review": "Review threat",
  "1 star": "Review threat",
  "one star": "Review threat",
  "bad review": "Review threat",
  "warn everyone": "Public warning threat",
  "expose you": "Public warning threat",

  // Injury / Medical
  injured: "Injury claim",
  "injured me": "Injury claim",
  allergic: "Allergic reaction",
  "allergic reaction": "Allergic reaction",
  hospital: "Medical emergency",
};

/**
 * Check if a message should be escalated.
 * @param {string} message - The incoming Instagram message
 * @param {string} [clientSystemPrompt] - Optional per-client escalation rules
 * @returns {{ escalate: boolean, reason: string | null }}
 */
function checkEscalation(message, clientSystemPrompt = "") {
  const lower = message.toLowerCase();

  // Check built-in triggers
  for (const [trigger, reason] of Object.entries(ESCALATION_TRIGGERS)) {
    if (lower.includes(trigger)) {
      return { escalate: true, reason };
    }
  }

  // Check client-specific triggers defined in their system prompt
  // Looks for "Escalate if the message contains: ..." pattern
  const match = clientSystemPrompt.match(/escalate if.*?contains?:([^\n]+)/i);
  if (match) {
    const customTriggers = match[1].split(",").map((t) => t.trim().toLowerCase());
    for (const trigger of customTriggers) {
      if (trigger && lower.includes(trigger)) {
        return { escalate: true, reason: `Custom rule: "${trigger}"` };
      }
    }
  }

  return { escalate: false, reason: null };
}

module.exports = { checkEscalation };
