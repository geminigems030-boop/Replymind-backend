// src/test-reply.js
// ─────────────────────────────────────────────────────────
// Run this BEFORE connecting Instagram to verify everything
// works: Claude API key, client config, escalation logic.
//
// Usage: node src/test-reply.js
// ─────────────────────────────────────────────────────────

require("dotenv").config();
const { generateReply } = require("./services/aiService");
const { checkEscalation } = require("./utils/escalationDetector");
const { getClient } = require("../config/clients");

const GREEN = "\x1b[32m";
const YELLOW = "\x1b[33m";
const RED = "\x1b[31m";
const RESET = "\x1b[0m";
const BOLD = "\x1b[1m";

const testCases = [
  {
    label: "GlamourHair — Normal DM (should reply)",
    clientId: "17841400000000001",
    messageType: "dm",
    fromUser: "@sarah.glam",
    message: "Hi! Do you do balayage and how much does it roughly cost?",
  },
  {
    label: "FitnessPro — Comment (should reply)",
    clientId: "17841400000000002",
    messageType: "comment",
    fromUser: "@mike_lifts99",
    message: "This workout looks impossible, I've been stuck at the same weight for months 😅",
  },
  {
    label: "LuxeBoutique — Normal DM (should reply)",
    clientId: "17841400000000003",
    messageType: "dm",
    fromUser: "@anna_nyc",
    message: "Is this bag available in black?",
  },
  {
    label: "GlamourHair — Complaint DM (should ESCALATE)",
    clientId: "17841400000000001",
    messageType: "dm",
    fromUser: "@angry_customer",
    message: "I came in last week and the stylist ruined my hair. I want a refund and I'm going to leave a terrible review.",
  },
  {
    label: "LuxeBoutique — Refund DM (should ESCALATE)",
    clientId: "17841400000000003",
    messageType: "dm",
    fromUser: "@upset_buyer",
    message: "I ordered 3 weeks ago and nothing arrived. I want my money back NOW.",
  },
];

async function runTests() {
  console.log(`\n${BOLD}ReplyMind — Pipeline Test${RESET}\n`);
  console.log("─".repeat(60));

  let passed = 0;
  let failed = 0;

  for (const test of testCases) {
    console.log(`\n${BOLD}TEST: ${test.label}${RESET}`);
    console.log(`  Client: ${test.clientId} | Type: ${test.messageType}`);
    console.log(`  Message: "${test.message}"`);

    const clientConfig = getClient(test.clientId);
    if (!clientConfig) {
      console.log(`  ${RED}✗ Client not found${RESET}`);
      failed++;
      continue;
    }

    // Check escalation first
    const { escalate, reason } = checkEscalation(test.message, clientConfig.systemPrompt);

    if (escalate) {
      console.log(`  ${YELLOW}⚠  ESCALATED — ${reason}${RESET}`);
      if (test.label.includes("ESCALATE")) {
        console.log(`  ${GREEN}✓ Correctly escalated${RESET}`);
        passed++;
      } else {
        console.log(`  ${RED}✗ Should NOT have been escalated${RESET}`);
        failed++;
      }
      continue;
    }

    // Generate AI reply
    try {
      const { reply, confidence } = await generateReply({
        message: test.message,
        messageType: test.messageType,
        fromUser: test.fromUser,
        clientConfig,
      });

      console.log(`  ${GREEN}✓ AI Reply (confidence: ${confidence})${RESET}`);
      console.log(`  Reply: "${reply}"`);

      if (test.label.includes("ESCALATE")) {
        console.log(`  ${RED}✗ Should have been escalated but wasn't${RESET}`);
        failed++;
      } else {
        passed++;
      }
    } catch (err) {
      console.log(`  ${RED}✗ Error: ${err.message}${RESET}`);
      failed++;
    }
  }

  console.log("\n" + "─".repeat(60));
  console.log(`\n${BOLD}Results: ${GREEN}${passed} passed${RESET}, ${failed > 0 ? RED : ""}${failed} failed${RESET}\n`);

  if (failed === 0) {
    console.log(`${GREEN}✅ All tests passed! Ready to connect Instagram.${RESET}\n`);
  } else {
    console.log(`${RED}❌ Some tests failed. Check your .env and config/clients.js${RESET}\n`);
  }
}

runTests();
