// src/services/instagramService.js
// ─────────────────────────────────────────────────────────
// Sends replies back to Instagram via the Graph API.
// Handles both DM replies and comment replies.
// ─────────────────────────────────────────────────────────

const axios = require("axios");

const BASE_URL = "https://graph.instagram.com/v21.0";
const ACCESS_TOKEN = process.env.INSTAGRAM_PAGE_ACCESS_TOKEN;

/**
 * Reply to an Instagram Direct Message.
 *
 * @param {string} recipientId - The IGSID (Instagram-scoped ID) of the sender
 * @param {string} message     - The reply text
 * @returns {Promise<object>}  - Meta API response
 */
async function replyToDM(recipientId, message) {
  const url = `${BASE_URL}/me/messages`;

  const response = await axios.post(
    url,
    {
      recipient: { id: recipientId },
      message: { text: message },
    },
    {
      params: { access_token: ACCESS_TOKEN },
      headers: { "Content-Type": "application/json" },
    }
  );

  return response.data;
}

/**
 * Reply to an Instagram post comment.
 *
 * @param {string} commentId - The ID of the comment to reply to
 * @param {string} message   - The reply text
 * @returns {Promise<object>}
 */
async function replyToComment(commentId, message) {
  const url = `${BASE_URL}/${commentId}/replies`;

  const response = await axios.post(
    url,
    { message },
    {
      params: { access_token: ACCESS_TOKEN },
      headers: { "Content-Type": "application/json" },
    }
  );

  return response.data;
}

/**
 * Get basic info about the connected Instagram account.
 * Useful for verifying your token is working.
 */
async function getAccountInfo() {
  const response = await axios.get(`${BASE_URL}/me`, {
    params: {
      fields: "id,username,name",
      access_token: ACCESS_TOKEN,
    },
  });
  return response.data;
}

module.exports = { replyToDM, replyToComment, getAccountInfo };
