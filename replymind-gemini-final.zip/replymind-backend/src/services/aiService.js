// src/services/aiService.js
// ─────────────────────────────────────────────────────────
// Generates AI replies using Google Gemini (free tier).
// Handles per-client system prompts and tone.
// ─────────────────────────────────────────────────────────

const axios = require("axios");

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

/**
 * Generate an AI reply for an incoming Instagram message.
 *
 * @param {object} params
 * @param {string} params.message       - The incoming message text
 * @param {string} params.messageType   - "dm" | "comment"
 * @param {string} params.fromUser      - Instagram username of sender
 * @param {object} params.clientConfig  - The client config object from clients.js
 * @returns {Promise<{ reply: string, confidence: number }>}
 */
async function generateReply({ message, messageType, fromUser, clientConfig }) {
  const contextNote =
    messageType === "comment"
      ? "This is a public Instagram comment on one of our posts."
      : "This is a private Instagram Direct Message.";

  const fullPrompt = `${clientConfig.systemPrompt}

---

${contextNote}
From: ${fromUser}
Message: "${message}"

Write a reply on behalf of ${clientConfig.name}.`;

  const response = await axios.post(GEMINI_URL, {
    contents: [{ parts: [{ text: fullPrompt }] }],
    generationConfig: { maxOutputTokens: 300, temperature: 0.8 },
  });

  const reply =
    response.data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "";

  const confidence = reply.length > 20 ? 0.92 : 0.6;

  return { reply, confidence };
}

module.exports = { generateReply };
