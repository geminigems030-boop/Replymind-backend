// src/services/replyPipeline.js
// ─────────────────────────────────────────────────────────
// The core pipeline. Given an incoming message event:
//   1. Find the client config
//   2. Check for escalation triggers
//   3. Generate an AI reply via Claude
//   4. Either send immediately or queue for review
//   5. Log everything
// ─────────────────────────────────────────────────────────

const { generateReply } = require("./aiService");
const { replyToDM, replyToComment } = require("./instagramService");
const { checkEscalation } = require("../utils/escalationDetector");
const { getClient } = require("../../config/clients");

// In-memory queues (replace with a database in production)
const replyQueue = [];
const escalationQueue = [];

/**
 * Process an incoming Instagram DM.
 *
 * @param {object} params
 * @param {string} params.pageId      - Instagram Page ID (identifies the client)
 * @param {string} params.senderId    - IGSID of the person who sent the DM
 * @param {string} params.senderName  - Username of sender (if available)
 * @param {string} params.message     - The message text
 */
async function processDM({ pageId, senderId, senderName, message }) {
  const client = getClient(pageId);

  if (!client) {
    console.warn(`[Pipeline] No client found for pageId: ${pageId}`);
    return;
  }

  if (!client.features.replyDMs) {
    console.log(`[Pipeline] DM replies disabled for ${client.name}`);
    return;
  }

  console.log(`[Pipeline] Processing DM for ${client.name} from ${senderName || senderId}`);

  return await runPipeline({
    client,
    messageType: "dm",
    senderId,
    senderName,
    message,
    replyFn: (text) => replyToDM(senderId, text),
  });
}

/**
 * Process an incoming Instagram comment.
 *
 * @param {object} params
 * @param {string} params.pageId      - Instagram Page ID
 * @param {string} params.commentId   - ID of the comment to reply to
 * @param {string} params.senderName  - Username of commenter
 * @param {string} params.message     - The comment text
 */
async function processComment({ pageId, commentId, senderName, message }) {
  const client = getClient(pageId);

  if (!client) {
    console.warn(`[Pipeline] No client found for pageId: ${pageId}`);
    return;
  }

  if (!client.features.replyComments) {
    console.log(`[Pipeline] Comment replies disabled for ${client.name}`);
    return;
  }

  console.log(`[Pipeline] Processing comment for ${client.name} from ${senderName}`);

  return await runPipeline({
    client,
    messageType: "comment",
    senderId: commentId,
    senderName,
    message,
    replyFn: (text) => replyToComment(commentId, text),
  });
}

/**
 * Core pipeline logic — shared by DM and comment handlers.
 */
async function runPipeline({ client, messageType, senderId, senderName, message, replyFn }) {
  const timestamp = new Date().toISOString();

  // ── Step 1: Check for escalation ──────────────────────
  if (client.features.escalation) {
    const { escalate, reason } = checkEscalation(message, client.systemPrompt);

    if (escalate) {
      const escalation = {
        id: `esc_${Date.now()}`,
        clientId: client.id,
        clientName: client.name,
        messageType,
        senderId,
        senderName,
        message,
        reason,
        status: "pending",
        createdAt: timestamp,
      };

      escalationQueue.push(escalation);
      console.log(`[Pipeline] ⚠️  ESCALATED for ${client.name} — Reason: ${reason}`);

      // TODO: Send email/Slack notification here
      // await sendEscalationNotification(escalation);

      return { status: "escalated", reason, escalationId: escalation.id };
    }
  }

  // ── Step 2: Generate AI reply ──────────────────────────
  let reply, confidence;
  try {
    ({ reply, confidence } = await generateReply({
      message,
      messageType,
      fromUser: senderName || senderId,
      clientConfig: client,
    }));
  } catch (err) {
    console.error(`[Pipeline] AI generation failed:`, err.message);
    return { status: "error", error: err.message };
  }

  // ── Step 3: Auto-send or queue for review ─────────────
  const autoApprove = process.env.AUTO_APPROVE === "true";

  if (autoApprove) {
    try {
      await replyFn(reply);
      console.log(`[Pipeline] ✅ Auto-sent reply for ${client.name}`);
      return { status: "sent", reply, confidence };
    } catch (err) {
      console.error(`[Pipeline] Failed to send reply:`, err.message);
      return { status: "error", error: err.message };
    }
  } else {
    // Queue for human review in the dashboard
    const queued = {
      id: `q_${Date.now()}`,
      clientId: client.id,
      clientName: client.name,
      messageType,
      senderId,
      senderName,
      message,
      aiReply: reply,
      confidence,
      status: "pending",
      replyFn: replyFn.toString(), // Note: store the actual fn reference in production
      createdAt: timestamp,
    };

    replyQueue.push(queued);
    console.log(`[Pipeline] 📬 Queued reply for ${client.name} (confidence: ${confidence})`);
    return { status: "queued", queueId: queued.id, reply, confidence };
  }
}

// ── Queue management (used by the API routes) ─────────────

function getQueue() {
  return replyQueue.filter((item) => item.status === "pending");
}

function getEscalations() {
  return escalationQueue.filter((item) => item.status === "pending");
}

function approveQueueItem(id, replyFn) {
  const item = replyQueue.find((i) => i.id === id);
  if (!item) return false;
  item.status = "approved";
  item.approvedAt = new Date().toISOString();
  return item;
}

function resolveEscalation(id) {
  const item = escalationQueue.find((i) => i.id === id);
  if (!item) return false;
  item.status = "resolved";
  item.resolvedAt = new Date().toISOString();
  return true;
}

module.exports = {
  processDM,
  processComment,
  getQueue,
  getEscalations,
  approveQueueItem,
  resolveEscalation,
};
