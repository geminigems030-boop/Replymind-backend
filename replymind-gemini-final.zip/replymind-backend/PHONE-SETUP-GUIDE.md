# 🚀 Deploy ReplyMind — Phone Only Guide

Follow these steps exactly, in order.

---

## STEP 1 — Get your Anthropic API Key

1. Open Safari → go to: https://console.anthropic.com
2. Sign up / log in
3. Click "API Keys" → "Create Key"
4. Copy the key (starts with sk-ant-)
5. Open the .env file in this folder
6. Replace YOUR_ANTHROPIC_KEY_HERE with your key

---

## STEP 2 — Upload to GitHub (from your phone)

1. Download the "GitHub" app from App Store
2. Create a free account at github.com
3. Tap "+" → "New repository"
4. Name it: replymind-backend
5. Set to PRIVATE (important!)
6. Create repository
7. Tap "Upload files" → upload ALL files from this folder

---

## STEP 3 — Deploy on Railway (free hosting)

1. Open Safari → go to: https://railway.app
2. Sign up with your GitHub account
3. Click "New Project" → "Deploy from GitHub repo"
4. Select: replymind-backend
5. Railway will auto-detect Node.js and deploy it
6. Once deployed, click your project → "Settings" → copy the PUBLIC URL
   It will look like: https://replymind-backend-production.up.railway.app

---

## STEP 4 — Add environment variables on Railway

1. In your Railway project → click "Variables"
2. Add each variable from the .env file:
   - ANTHROPIC_API_KEY = your key
   - INSTAGRAM_APP_SECRET = da5c07c339fd343142a0645e293c965a
   - INSTAGRAM_PAGE_ACCESS_TOKEN = EAAb6HZC...
   - INSTAGRAM_VERIFY_TOKEN = transform_secret_2024
   - NODE_ENV = production
   - AUTO_APPROVE = false
3. Railway will auto-restart with new variables

---

## STEP 5 — Connect webhook to Meta

1. Go to: developers.facebook.com/apps
2. Your app → Instagram → API Setup
3. Scroll to "Configure webhooks"
4. Callback URL: https://YOUR-RAILWAY-URL/webhook/instagram
5. Verify Token: transform_secret_2024
6. Click "Verify and Save"
7. Subscribe to: messages + comments

---

## STEP 6 — Test it!

Send a DM to @transformegypt from another account.
The AI should reply automatically! 🎉

---

## Your credentials summary:
- Page ID: 103171268935229
- Verify Token: transform_secret_2024
- App Secret: da5c07c339fd343142a0645e293c965a
- Token expires: in ~60 days (refresh it before then)
