# ReplyMind — Instagram AI Agent Backend

Node.js/Express backend that powers the ReplyMind dashboard.
Handles Instagram webhooks, runs messages through Claude AI,
detects escalations, and sends replies via the Instagram Graph API.

---

## Architecture

```
Instagram DM/Comment
        │
        ▼
POST /webhook/instagram
        │
        ▼
  Signature Verify  ──── FAIL ──▶ Ignore
        │ PASS
        ▼
  Escalation Check  ──── YES ───▶ Escalation Queue → Dashboard
        │ NO
        ▼
  Claude AI (generateReply)
        │
        ▼
  AUTO_APPROVE=true?
  ├── YES ──▶ Send via Instagram API immediately
  └── NO  ──▶ Reply Queue → Dashboard → Human approves → Send
```

---

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Open `.env` and fill in:
- `ANTHROPIC_API_KEY` — from https://console.anthropic.com
- `INSTAGRAM_VERIFY_TOKEN` — make up any random string (e.g. `replymind_secret_abc123`)
- `INSTAGRAM_APP_SECRET` — from your Meta App settings
- `INSTAGRAM_PAGE_ACCESS_TOKEN` — long-lived token from Meta (see connection guide below)

### 3. Add your clients

Open `config/clients.js` and replace the example Page IDs with your real Instagram Page IDs.
Customize each client's name, tone, and system prompt.

**Finding your Instagram Page ID:**
- Go to your Facebook Page
- Click "About" → scroll to the bottom
- You'll see "Page ID: 123456789..."
- Or use: `https://graph.facebook.com/me?fields=id,name&access_token=YOUR_TOKEN`

### 4. Test locally (no Instagram needed yet)

```bash
npm test
```

This runs 5 test cases through the full pipeline (AI generation + escalation detection)
without actually sending anything to Instagram.

### 5. Start the server

```bash
npm run dev     # development (auto-restart on changes)
npm start       # production
```

---

## Connecting to Instagram — Step by Step

### Step 1: Create a Meta Developer App

1. Go to **https://developers.facebook.com**
2. Click **My Apps** → **Create App**
3. Choose **Business** as app type
4. Give it a name (e.g. "ReplyMind")
5. Click **Create App**

### Step 2: Add Instagram to your app

1. In your app dashboard, click **Add Product**
2. Find **Instagram** → click **Set Up**
3. Choose **Instagram API with Instagram Login** (for business accounts)

### Step 3: Connect your Instagram Business Account

1. Go to **Instagram** → **API setup with Instagram Login**
2. Under "Generate access tokens", click **Add Instagram testers**
3. Add the Instagram accounts you want to manage
4. Each account owner must accept the tester invite (check instagram.com/accounts/manage_access/)
5. Once accepted, click **Generate token** next to each account
6. Copy the token — this is your `INSTAGRAM_PAGE_ACCESS_TOKEN`

> ⚠️ Tokens expire after 60 days. Use the token refresh endpoint to keep them alive:
> `GET https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=TOKEN`

### Step 4: Expose your server to the internet

Meta needs to reach your webhook URL. In development, use **ngrok**:

```bash
# Install ngrok: https://ngrok.com/download
ngrok http 3000
```

This gives you a URL like: `https://abc123.ngrok.io`

Your webhook URL will be: `https://abc123.ngrok.io/webhook/instagram`

In production, deploy to Railway, Render, Heroku, or a VPS and use your real domain.

### Step 5: Register the webhook in Meta

1. In your Meta App, go to **Instagram** → **Webhooks**
2. Click **Subscribe to Events**
3. Enter:
   - **Callback URL**: `https://YOUR-DOMAIN/webhook/instagram`
   - **Verify Token**: exactly what you set in `.env` as `INSTAGRAM_VERIFY_TOKEN`
4. Click **Verify and Save**

If it says ✅ Verified — your server is connected!

### Step 6: Subscribe to the right events

After verification, subscribe to these fields:
- ✅ `messages` — for DMs
- ✅ `comments` — for post comments
- ✅ `mentions` — optional (if you want to reply to story mentions)

### Step 7: Set App to Live mode

1. Go to **App Settings** → **Basic**
2. Toggle the app from **Development** to **Live**
3. This allows real Instagram users (not just testers) to trigger the webhook

> 📌 Note: For production use with real users, you may need to submit for **App Review** 
> if you need advanced permissions beyond your own accounts.

---

## API Reference

### Generate reply (manual / test)
```
POST /api/reply
Content-Type: application/json

{
  "client_id": "17841400000000001",
  "message_type": "dm",
  "from_user": "@username",
  "message": "Do you do balayage?",
  "auto_send": false
}
```

### Get pending reply queue
```
GET /api/queue
GET /api/queue?client_id=17841400000000001
```

### Approve a queued reply
```
POST /api/queue/:id/approve
```

### Approve with edited text
```
POST /api/queue/:id/approve-edited
{ "edited_reply": "Your custom reply text" }
```

### Get escalations
```
GET /api/escalations
GET /api/escalations?status=pending
```

### Resolve an escalation
```
POST /api/escalations/:id/resolve
```

### List clients
```
GET /api/clients
```

### Health check (also verifies Instagram connection)
```
GET /api/health
```

---

## File Structure

```
replymind-backend/
├── src/
│   ├── index.js                    # Express server entry point
│   ├── routes/
│   │   ├── webhook.js              # Instagram webhook (GET verify + POST events)
│   │   └── api.js                  # Dashboard REST API
│   ├── services/
│   │   ├── aiService.js            # Claude AI reply generation
│   │   ├── instagramService.js     # Instagram Graph API (send DMs/comments)
│   │   └── replyPipeline.js        # Core orchestrator
│   └── utils/
│       └── escalationDetector.js  # Keyword-based escalation detection
├── config/
│   └── clients.js                  # Client profiles & system prompts
├── .env.example                    # Environment variable template
├── package.json
└── README.md
```

---

## Going to Production

- Replace in-memory queues in `replyPipeline.js` with a real database (Postgres + Prisma recommended)
- Add authentication to the `/api/*` routes (JWT or API keys)
- Set up token refresh cron job for Instagram access tokens (expire every 60 days)
- Use a job queue (Bull/BullMQ + Redis) for reliable async processing
- Deploy on Railway, Render, or a VPS with a real domain + SSL

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ | Your Anthropic API key |
| `INSTAGRAM_VERIFY_TOKEN` | ✅ | Random string you choose for webhook verification |
| `INSTAGRAM_APP_SECRET` | ✅ | From Meta App Settings → Basic |
| `INSTAGRAM_PAGE_ACCESS_TOKEN` | ✅ | Long-lived Instagram user token |
| `PORT` | optional | Server port (default: 3000) |
| `AUTO_APPROVE` | optional | `true` to send replies without review (default: false) |
| `NODE_ENV` | optional | `development` or `production` |
